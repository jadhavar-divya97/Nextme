import React from 'react';
import Login from './auth/Login';
import SignUp from './auth/SignUp';
import { Link, Route, Routes } from 'react-router-dom';
import Home from './Home';
import About from './About';
import NavBar from './Components/NavBar';

export default function Next() {
    return (
        <div className='text-white'>
            <NavBar/>
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/signup" element={<SignUp />} />
               <Route path="/home" element={<Home />} />
                <Route path="/about" element={<About />} />
           </Routes>
        </div>
    );
}
